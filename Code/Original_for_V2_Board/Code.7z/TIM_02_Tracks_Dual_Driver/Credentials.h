#pragma once
/*
  The name of your local network.
  The Password.

	These are required if using the "Station (STA) mode".
*/
const char* LOCAL_SSID_STA = "???????????";		/*	Your local network name.		*/
const char* LOCAL_PASSWORD_STA = "???????????";	/*	Your local network password.	*/
